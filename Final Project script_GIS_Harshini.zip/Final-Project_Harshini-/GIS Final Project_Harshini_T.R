
# Setup -------------------------------------------------------------------

##Loading required libraries
library(dplyr)
library(ggplot2)
library(readr)

# Data --------------------------------------------------------------------

#Loading required data
ebola <- ## cases data
  read_csv('data/raw/Ebola_Virus_Outbreak.csv')
guinea <- ## guinea socioeconomic variable data
  read_csv('data/raw/guinea_sev.csv')
liberia <- ## liberia socioeconomic variable data
  read_csv('data/raw/lib_sev.csv')
sierra_leone <- ## sierra leone socioeconomic variable data
  read_csv('data/raw/sierra_sev.csv')

# Data Processing ---------------------------------------------------------

#Filtering final cumulative cases in each county 
ebola <- ##dropping zero case value columns 
  ebola[apply(ebola!=0,1,all),]
ebola %>%
  group_by(location) %>% ##county wise final case count
  filter(Cumulative_cases == max(Cumulative_cases)) %>% ##final case count
  ungroup()

#Filtering final cumulative cases in each county-removing duplicates
ebola <- ebola %>%
  arrange(desc(date_)) %>% ##to get the result of latest date
  group_by(location) %>%##county wise grouping
  slice(1)##dropping duplicates
head(ebola)

# Data exploration --------------------------------------------------------

##creating custom theme for text in the plot
custom_Theme = theme(
  axis.title.x = element_text(size = 16),
  axis.text.x =   element_text(size = 10),
  axis.title.y = element_text(size = 16),
  axis.text.y =   element_text(size = 7))
ebola$location <- tolower(ebola$location) #converting location to lowercase
# Scatterplot of Countywise total cases
ggplot(ebola,aes(x=Cumulative_cases, y=location)) + ##ggplot base layer
  geom_point() + geom_smooth()+ ##adding maping point
  labs(title="Scatterplot of Countywise total cases", x="Total cases", y="County")+
  custom_Theme # add axis lables and plot title
#Barplot Countrywise total cases
ebola_country<- ebola %>% ##exploratory plot 2 country wise case count
  group_by(country)%>% 
  summarise(Cumulative_cases = sum(Cumulative_cases))  
##plot
ggplot(ebola_country, aes(x=Cumulative_cases, y=country)) + 
  geom_point()

# Creating final dataset --------------------------------------------------

merge1 <- ## merging guinea and liberia files
  rbind(guinea,liberia)

merge2 <-## merging guinea,liberia and sierra leone files
  rbind(merge1,sierra_leone)
merge2$location <- tolower(merge2$location)##converting location to lowercase
## merge final 
final_data <- merge(ebola,merge2,by="location") #regression line


# Preliminary Statistical analysis ----------------------------------------

# Results 1 - running regression model - Single variable
results1 <- lm(Cumulative_cases ~ Gross_National_Income_per_capita,  data = final_data)
# showing results 
summary(results1)

# Scatterplot 
plot(jitter(final_data$Gross_National_Income_per_capita, 2), jitter(final_data$Cumulative_cases, 2), 
     type = "p", pch  = 20, xlab = "Gross_National_Income_per_capita", ylab = "Cumulative_cases",
     main = "Relationship between Gross National Income and Cummulative cases")
# using abline() to fit the regression 
abline(a = coef(results1)[1], b = coef(results1)[2], col = 2) #regression line

# Result2 - running regression model - Single variable
results2 <- lm(Cumulative_cases ~ Percentage_poorest_households, data = final_data)
# showing results 
summary(results2)

# Scatterplot 
plot(jitter(final_data$Percentage_poorest_households, 2), jitter(final_data$Cumulative_cases, 2), 
     type = "p", pch  = 20, xlab = "Percentage_poorest_households", ylab = "Cumulative_cases",
     main = "Relationship between % of poorest households and Cummulative cases")
# using abline() to fit the regression 
abline(a = coef(results2)[1], b = coef(results2)[2], col = 2) #regression line

# Result3 - running regression model - Single variable
results3 <- lm(Cumulative_cases ~ Mean_years_education_population, data = final_data)
# showing results 
summary(results3)
# Scatterplot 
plot(jitter(final_data$Mean_years_education_population, 2), jitter(final_data$Cumulative_cases, 2), 
     type = "p", pch  = 20, xlab = "Mean_years_education_population", ylab = "Cumulative_cases",
     main = "Relationship between Mean years of education and Cummulative cases")
# using abline() to fit the regression 
abline(a = coef(results2)[1], b = coef(results2)[2], col = 2)



# Multivariate analysis ---------------------------------------------------

# run model with all the variables 
result4 <- lm(Cumulative_cases ~ Gross_National_Income_per_capita + Percentage_poorest_households + Mean_years_education_population, data = final_data)
# view results
summary(result4)$coefficients 

# run model with scaled variables 
result4 <- lm(scale(Cumulative_cases) ~ scale(Gross_National_Income_per_capita) + scale(Percentage_poorest_households) + scale(Mean_years_education_population), data = final_data)
# view results
summary(result4)$coefficients 




