# setup -------------------------------------------------------------------
library(readxl)
library(lubridate)
library(sf)
library(leaflet)

library(shiny) 
library(shinyWidgets)
library(shinydashboard)
library(tidyverse)
library(tmap)
library(maps)
library(mapproj)
library(ggplot2)

#  TODO line 92 data filtered on selection --------------------------------------------------------------------


##Ebola data
ebola <- read_csv('Ebola_Virus_Outbreak.csv')


ui <- dashboardPage(
  dashboardHeader(title = "Ebola Dashboard"),
  dashboardSidebar( 
    
    dateInput(
      "date1", "Date:", format = "dd-mm-yyyy",
      value = min(ebola$date_),
      min = min(ebola$date_),
      max = max(ebola$date_)
      
    ),
    
    
    selectInput(
      inputId = 'state_select',
      label = 'Country',
      choices = c('Select Country',unique(ebola$country))
    ),
    
    conditionalPanel("input.state_select",
                     selectInput(  inputId = 'city_select', label = 'City', c("Select city"="") )
    )  
  ),
  dashboardBody(
    
    
    leafletOutput("ebolamap")
  )
)



server <- function(input, output, session){
  set.seed(3535)
  
  observe({
    locations <- if (is.null(input$state_select)) character(0) else {
      filter(ebola, country %in% input$state_select) %>%
        `$`('location') %>%
        unique() %>%
        sort()
    }
    stillSelected <- isolate(input$locations[input$locations %in% locations])
    updateSelectizeInput(session, "city_select", choices = locations,
                         selected = stillSelected, server = TRUE)
  })
  
  
  
  
  
  df <- data.frame(latitude = sample(seq(6.5, 8.5, by = 0.01), 100),
                   longitude = sample(seq(-13.0, -10.0, by = 0.01), 100),
                   value = seq(1,100)
  )
  
  #  df <- ebola[,c("A","B","K" )] 
  
  ## create static element
  output$ebolamap <- renderLeaflet({
    
    leaflet() %>%
      addTiles() %>%
      addProviderTiles('Hydda.Full') %>%
      setView(lng = -10.81544453, lat = 6.698632754, zoom = 6)
    #    setView(lat = -37.8, lng = 144.8, zoom = 8)
    
  })
  
  ## filter data
  #    df_filtered <- reactive({
  #     ebola %>% 
  #        filter(country == input$state_select, location == input$city_select, date_ == input$date1 )
  
  #    })
  df_filtered <- reactive({
    df[df$value >= 2, ]
  })
  
  
  ## respond to the filtered data
  observe({
    selectedCountry <- input$state_select
    selectedCity <- input$city_select
    
    
    
    leafletProxy(mapId = "ebolamap", data = df_filtered()) %>%
      clearMarkers() %>%   ## clear previous markers
      addMarkers()
  })
  
}

shinyApp(ui, server) 